using System;
using System.Collections.Generic;

namespace CarWash.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int CustomerId { get; set; } 
        public int? WasherId { get; set; }  
        public int CardId { get; set; }        
        public int PackageId { get; set; }    
        public int? PromoCodeId { get; set; } 
        public string OrderNumber { get; set; } = string.Empty;
        public DateTime OrderDate { get; set; }
        public DateTime ScheduleDate { get; set; }
        public string Status { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }

       
        public virtual User Customer { get; set; }
        public virtual User? Washer { get; set; } 
        public virtual Payment Payment { get; set; }
        public virtual Package Package { get; set; }
        public virtual PromoCode? PromoCode { get; set; }
        public virtual ICollection<OrderAddOn> OrderAddOns { get; set; }
        public virtual ICollection<Report> Reports { get; set; }

        public Order()
        {
            OrderAddOns = new HashSet<OrderAddOn>();
            Reports = new HashSet<Report>();
        }
    }
}
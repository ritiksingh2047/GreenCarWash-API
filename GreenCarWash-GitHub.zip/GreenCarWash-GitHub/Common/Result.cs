namespace CarWash.Common
{
    public class Result<T>
    {
        public bool IsSuccess { get; private set; }
        public T? Data { get; private set; }
        public string? Error { get; private set; }
        public List<string> ValidationErrors { get; private set; } = new();

        private Result() { }

        public static Result<T> Success(T data)
        {
            return new Result<T>
            {
                IsSuccess = true,
                Data = data
            };
        }

        public static Result<T> Failure(string error)
        {
            return new Result<T>
            {
                IsSuccess = false,
                Error = error
            };
        }

        public static Result<T> ValidationFailure(List<string> validationErrors)
        {
            return new Result<T>
            {
                IsSuccess = false,
                Error = "Validation failed",
                ValidationErrors = validationErrors
            };
        }
    }

    public class Result
    {
        public bool IsSuccess { get; private set; }
        public string? Error { get; private set; }
        public List<string> ValidationErrors { get; private set; } = new();

        private Result() { }

        public static Result Success()
        {
            return new Result { IsSuccess = true };
        }

        public static Result Failure(string error)
        {
            return new Result
            {
                IsSuccess = false,
                Error = error
            };
        }

        public static Result ValidationFailure(List<string> validationErrors)
        {
            return new Result
            {
                IsSuccess = false,
                Error = "Validation failed",
                ValidationErrors = validationErrors
            };
        }
    }
}

using System.Net;
using System.Text.Json;
using CarWash.Interfaces;

namespace CarWash.Middleware
{
    public class GlobalExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<GlobalExceptionMiddleware> _logger;
        private readonly IServiceProvider _serviceProvider;

        public GlobalExceptionMiddleware(RequestDelegate next, ILogger<GlobalExceptionMiddleware> logger, IServiceProvider serviceProvider)
        {
            _next = next;
            _logger = logger;
            _serviceProvider = serviceProvider;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An unhandled exception occurred: {Message}", ex.Message);
                
                // Log to database if possible
                try
                {
                    using var scope = _serviceProvider.CreateScope();
                    var logService = scope.ServiceProvider.GetService<ILogService>();
                    if (logService != null)
                    {
                        await logService.LogAsync("Error", $"Global exception: {ex.Message}", ex.ToString());
                    }
                }
                catch (Exception logEx)
                {
                    _logger.LogError(logEx, "Failed to log exception to database");
                }

                await HandleExceptionAsync(context, ex);
            }
        }

        private static async Task HandleExceptionAsync(HttpContext context, Exception ex)
        {
            context.Response.ContentType = "application/json";
            
            var (statusCode, message) = ex switch
            {
                ArgumentNullException => (HttpStatusCode.BadRequest, "Required data is missing"),
                ArgumentException => (HttpStatusCode.BadRequest, "Invalid request data"),
                UnauthorizedAccessException => (HttpStatusCode.Unauthorized, "Unauthorized access"),
                KeyNotFoundException => (HttpStatusCode.NotFound, "Resource not found"),
                InvalidOperationException => (HttpStatusCode.BadRequest, "Invalid operation"),
                NotImplementedException => (HttpStatusCode.NotImplemented, "Feature not implemented"),
                TimeoutException => (HttpStatusCode.RequestTimeout, "Request timeout"),
                _ => (HttpStatusCode.InternalServerError, "An internal server error occurred")
            };

            context.Response.StatusCode = (int)statusCode;

            var response = new
            {
                error = new
                {
                    message = message,
                    statusCode = (int)statusCode,
                    timestamp = DateTime.UtcNow,
                    path = context.Request.Path.Value
                }
            };

            var jsonResponse = JsonSerializer.Serialize(response, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            await context.Response.WriteAsync(jsonResponse);
        }
    }
}

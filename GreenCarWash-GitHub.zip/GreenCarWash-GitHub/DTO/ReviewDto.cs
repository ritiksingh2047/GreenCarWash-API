using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarWash.DTO
{
    public class ReviewDto
    {
        public int OrderId { get; set; }
        public required string Comment { get; set; }
        public int Rating { get; set; }
    }
}

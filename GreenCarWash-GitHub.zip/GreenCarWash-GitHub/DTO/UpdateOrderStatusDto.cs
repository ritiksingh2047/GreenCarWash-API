using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CarWash.DTO
{
    public class UpdateOrderStatusDto
    {
        [Required(ErrorMessage = "Status is required.")]
        [RegularExpression("^(Ongoing|Canceled|Completed)$", ErrorMessage = "Status must be 'Ongoing', 'Canceled', or 'Completed'.")]
        public required string Status { get; set; }
    }

}